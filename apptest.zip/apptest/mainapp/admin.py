from django.contrib import admin
from .models import Book, Category, relBookCategory


# Register your models here.
admin.site.register(Book)
admin.site.register(Category)
#admin.site.register(relBookCategory)



title = "Panel de gestión"
subtitle = "Proyecto biblioteca"

#config del panel
admin.site.site_header = title
admin.site.site_title = title
admin.site.index_title = subtitle