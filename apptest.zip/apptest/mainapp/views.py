from django.shortcuts import render, HttpResponse
from mainapp.models import Book, Category, relBookCategory
import pprint

# Create your views here.
def index(request):
    return render(request, 'mainapp/index.html', {'title': 'Inicio'})

def instructions(request):
    return render(request, 'mainapp/instructions.html', {'title': 'instructions'})



def addbook(request):
    return render(request, 'mainapp/addBook.html', {'title': 'Agregar un libro'})    


def saveBook(request):
    if request.method == "POST":
        title = request.POST['inputTitle']
        author = request.POST['inputAuthor']
        cover = request.POST['inputCover']
        categorys_id = request.POST['formats_id']

    if categorys_id == '':
        return HttpResponse("No tienes una categoria seleccionada")
    else:
        book = Book(
            title = title,
            author = author,
            cover = cover
        )
        book.save()

        # lastId = Book.objects.latest('id')
        # str = categorys_id
        # arr = str.split('|')

        # for i in range(0, len(arr), 1) :
        #     intId = int(arr[i])
        #     if (intId != ''):
        #         book_category = relBookCategory(
        #             id_book = lastId,
        #             id_category = intId
        #         )
        #         book_category.save()

        return render(request, 'mainapp/index.html', {'title': 'Inicio'})


    

 

    