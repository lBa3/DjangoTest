from mainapp.models import Book, Category, relBookCategory

def getBooks(request):
    books = Book.objects.values_list('id', 'title', 'author', 'cover')
    return {
        'books': books
    }


def getCategorys(request):
    category = Category.objects.values_list('id', 'name')
    return {
        'categorys': category
    }


def getRelBookCategorys():
    relation = relBookCategory.objects.values_list('id')
    return {
        'relation': relation
    }